import { extendType } from "nexus";

export const mutation_category = extendType({
    type: "Mutation",
    definition(t) {
    }
});