import { extendType } from "nexus";

export const query_admin = extendType({
    type: "Query",
    definition(t) {
    }
});